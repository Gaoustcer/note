//#include<stdio.h>
#include<string>
#include<iostream>
#include<string.h>
#include "instruction.h"
using namespace std;
int main(){
    short memory[65536]={0};
    short Register[8]={0};
    char Instruction[65536][20]={'\0'};//Max instruction number is 1000 and each instruction's length can be 20
    int PC=0;//program counter
    bool ZERO=false,POSITIVE=false,NAGATIVE=false;
    symbol *list_symbol=NULL;
    string inst;
    char *opcode;
    int start_instr;
    char tag_symbol[10];
    bool Imminstr=false;
    int DP,SR1,SR2;
    int Immnumber;
    int i=0;
    int ORIPC=0;
    while(1){
        gets((char*)(Instruction+i));
        if(strcmp((char*)(Instruction+i),"HALT")==0){
            break;
        }
        if(Instruction[i][0]=='.'&&Instruction[i][1]=='O'&&Instruction[i][2]=='R'){
            for(int i=7;Instruction[PC][i];i++){
                ORIPC=ORIPC*10;
                ORIPC+=Instruction[PC][i]-'0';
            }
            i=ORIPC;
            i++;
            continue;
        }
        cout<<"The Instruction is "<<(char *)(Instruction+i)<<endl;
        i++;
        if(returninstrtype((char*)(Instruction+i-1))!=0){
            int i=0;
            for(i=0;Instruction[PC][i]!=':';i++){
                tag_symbol[i]=Instruction[PC][i];
            }
            tag_symbol[i]='\0';

            for(i=i++;Instruction[PC][i]!=' ';i++){

            }
            start_instr=i;
            opcode=returnopcode(&Instruction[PC][i]);
            symbol *temp;
            for(temp=list_symbol;temp!=NULL;temp=temp->next){

            }
            temp=(symbol*)malloc(sizeof(symbol));
            temp->name=tag_symbol;
            temp->next=NULL;
            temp->PC=PC;
        }
    }
    int MAXinstr=i;
    PC=ORIPC+1;
    int breakpoint;
    printf("Input the breakpoint");
    scanf("%d",&breakpoint);
    while(1){
        if(strcmp((char*)(Instruction+PC),"HALT")==0){
            printf("This is the end of Analyze and We can answer your request\n");
            break;
        }
        else if(PC==breakpoint)
            break;
        else{
            if(returninstrtype((char*)(Instruction+PC))==0){
                opcode=returnopcode((char*)(Instruction+PC));
                start_instr=0;
            }//if not a command instruction with a symbol
            else{
                int i=0;
                for(i=0;Instruction[PC][i]!=':';i++){
                    tag_symbol[i]=Instruction[PC][i];
                }
                tag_symbol[i]='\0';
                for(i=i++;Instruction[PC][i]!=' ';i++){

                }
                start_instr=i;
                opcode=returnopcode(&Instruction[PC][i]);
            }
        }
        if(strcmp(opcode,ADD)==0){
            Imminstr=false;
            if(Instruction[PC][start_instr+10]=='#'){
                Imminstr=true;
            }
            else{
                Imminstr=false;
            }
            DP=Instruction[PC][start_instr+5]-'0';
            SR1=Instruction[PC][start_instr+8]-'0';
            SR2=Instruction[PC][start_instr+11]-'0';
            if(Imminstr){
                Immnumber=0;
                for(int i=11;Instruction[PC][i]!='\0';i++){
                    Immnumber=Immnumber*10;
                    Immnumber=Immnumber+Instruction[PC][i]-'0';
                }
                Register[DP]=Register[SR1]+Immnumber;

            }
            else{
                Register[DP]=Register[SR1]+Register[SR2];
            }
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(strcmp(opcode,AND)==0){
            Imminstr=false;
            if(Instruction[PC][start_instr+10]=='#'){
                Imminstr=true;
            }
            else{
                Imminstr=false;
            }
            DP=Instruction[PC][start_instr+5]-'0';
            SR1=Instruction[PC][start_instr+8]-'0';
            SR2=Instruction[PC][start_instr+11]-'0';
            if(Imminstr){
                Immnumber=0;
                for(int i=11;Instruction[PC][i]!='\0';i++){
                    Immnumber=Immnumber*10;
                    Immnumber=Immnumber+Instruction[PC][i]-'0';
                }
                Register[DP]=Register[SR1]&Immnumber;

            }
            else{
                Register[DP]=Register[SR1]&Register[SR2];
            }
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(opcode[0]=='B'){
            if(strcmp(opcode,"BRN")==0){
                returnjumptarget(&Instruction[PC][start_instr+4]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(NAGATIVE){
                    PC=find(list_symbol,target);
                }
                else{
                    PC=PC+1;
                }
            }
            else if(strcmp(opcode,"BRZ")==0){
                returnjumptarget(&Instruction[PC][start_instr+4]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(ZERO){
                    PC=find(list_symbol,target);
                }
                else{
                    PC++;
                }
            }
            else if(strcmp(opcode,"BRP")==0){
                returnjumptarget(&Instruction[PC][start_instr+4]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(POSITIVE){
                    PC=find(list_symbol,target);
                }
                else{
                    PC++;
                }
            }
            else if(strcmp(opcode,"BR")==0){
                returnjumptarget(&Instruction[PC][start_instr+3]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else{
                    PC=find(list_symbol,target);
                }
            }
            else if(strcmp(opcode,"BRZP")==0){
                returnjumptarget(&Instruction[PC][start_instr+5]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(ZERO|POSITIVE){
                    PC=find(list_symbol,target);
                }
                else{
                    PC++;
                }
            }
            else if(strcmp(opcode,"BRNP")==0){
                returnjumptarget(&Instruction[PC][start_instr+5]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(NAGATIVE|POSITIVE){
                    PC=find(list_symbol,target);
                }
                else{
                    PC++;
                }
            }
            else if(strcmp(opcode,"BRNZ")==0){
                returnjumptarget(&Instruction[PC][start_instr+5]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else if(NAGATIVE|ZERO){
                    PC=find(list_symbol,target);
                }
                else{
                    PC++;
                }
            }
            else if(strcmp(opcode,"BRNZP")==0){
                returnjumptarget(&Instruction[PC][start_instr+6]);
                string target(jump_target);
                if(find(list_symbol,target)==0){
                    printf("Error!,No such symbol\n");
                    return 0;
                }
                else{
                    PC=find(list_symbol,target);
                }
            }
            else{
                printf("Wrong branch instruction\n");
                return 0;
            }

        }
        else if(strcmp(opcode,JMP)==0){
            DP=Instruction[PC][start_instr+5]-'0';
            PC=Register[DP];
        }
        else if(strcmp(opcode,JSR)==0){
            returnjumptarget(&Instruction[PC][start_instr+4]);
            string target(jump_target);
            Register[7]=PC+1;
            if(find(list_symbol,target)==0){
                printf("Error!,No such symbol\n");
                return 0;
            }
            else{
                PC=find(list_symbol,target);
            }
        }
        else if(strcmp(opcode,JSRR)==0){
            DP=Instruction[PC][6+start_instr]-'0';
            Register[7]=PC+1;
            PC=Register[DP];
        }
        else if(strcmp(opcode,LD)==0){
            int offset=0;
            for(int i=6;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][4+start_instr]-'0';
            Register[DP]=memory[PC+1+offset];
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(strcmp(opcode,LDI)==0){
            int offset=0;
            for(int i=7;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][5+start_instr]-'0';
            Register[DP]=memory[memory[PC+1+offset]];
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(strcmp(opcode,LDR)==0){
            int offset=0;
            for(int i=10;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][5+start_instr]-'0';
            SR1=Instruction[PC][8+start_instr]-'0';
            Register[DP]=memory[Register[SR1]+offset];
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(strcmp(opcode,LEA)==0){
            int offset=0;
            for(int i=7;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][start_instr+5]-'0';
            Register[DP]=offset+PC+1;
            ZERO=false;
            NAGATIVE=false;
            POSITIVE=false;
            if(Register[DP]>0){
                POSITIVE=true;
            }
            else if(Register[DP]==0){
                ZERO=true;
            }
            else{
                NAGATIVE=true;
            }
            PC++;
        }
        else if(strcmp(opcode,NOT)==0){
            DP=Instruction[PC][start_instr+5]-'0';
            SR1=Instruction[PC][start_instr+8]-'0';
            Register[DP]=!Register[SR1];
        }
        else if(strcmp(opcode,RET)==0){
            PC=Register[7];
        }
        else if(strcmp(opcode,RTI)==0){
            printf("Error!\n");
            return 0;
        }
        else if(strcmp(opcode,ST)==0){
            int offset=0;
            for(int i=7;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][start_instr+4]-'0';
            memory[PC+1+offset]=Register[DP];
            PC++;
        }
        else if(strcmp(opcode,STR)==0){
            int offset=0;
            for(int i=10;Instruction[PC][i+start_instr]!='\0';i++){
                offset=offset*10;
                offset+=Instruction[PC][i+start_instr]-'0';
            }
            DP=Instruction[PC][start_instr+5]-'0';
            SR1=Instruction[PC][start_instr+8]-'0';
            memory[Register[SR1]+offset]=Register[DP];
            PC++;
        }
        else if(strcmp(opcode,TRAP)==0){
            printf("Not support for System call");
        }
        else{
            printf("Invalid Instruction and will return\n");
            return 0;
        }
    }
    //printf("%d",sizeof(short));
    while(1){
        printf("If you want to see the memory,put M;\nif you want to see the register_file,put RF;\n if you want to see the PC,put PC\n No request,put No\n");
        char command[5];
        scanf("%s",command);
        if(strcmp(command,"PC")==0){
            printf("The PC is %d\n",PC);

        }
        else if(strcmp(command,"M")==0){
            int memadd;
            printf("Input the Memory addr\n");
            scanf("%d",&memadd);
            printf("The Memory location is %d\n",memory[memadd]);
        }
        else if(strcmp(command,"RF")==0){
            int memadd;
            printf("Input the Register addr\n");
            scanf("%d",&memadd);
            printf("The Register location is %d\n",Register[memadd]);
        }
        else if(strcmp(command,"No")==0){
            printf("GoodBye\n");
            break ;
        }
        else{
            printf("Not valid\n");
        }
    }
    return 0;
}