#define ADD "ADD"
#define AND "AND"
#define BR "BR"
#define JMP "JMP"
#define JSR "JSR"
#define JSRR "JSRR"
#define LD "LD"
#define LDI "LDI"
#define LDR "LDR"
#define LEA "LEA"
#define NOT "NOT"
#define RET "RET"
#define RTI "RTI"
#define ST "ST"
#define STR "STR"
#define TRAP "TRAP"
#define SYMBOL 1
#define COMMAN 0
#include<string.h>
#include<string>
using namespace std;
char* compareopcode(char *opcode){
    if(strcmp(opcode,ADD)==0){
        return ADD;
    }
    else if(strcmp(opcode,AND)==0){
        return AND;
    }
    else if(strcmp(opcode,BR)==0){
        return BR;
    }
    else if(strcmp(opcode,JMP)==0){
        return JMP;
    }
    else if(strcmp(opcode,JSR)==0){
        return JSR;
    }
    else if(strcmp(opcode,JSRR)==0){
        return JSRR;
    }
    else if(strcmp(opcode,LD)==0){
        return LD;
    }
    else if(strcmp(opcode,LDI)==0){
        return LDI;
    }
    else if(strcmp(opcode,LDR)==0){
        return LDR;
    }
    else if(strcmp(opcode,LEA)==0){
        return LEA;
    }
    else if(strcmp(opcode,NOT)==0){
        return NOT;
    }
    else if(strcmp(opcode,RET)==0){
        return RET;
    }
    else if(strcmp(opcode,RTI)==0){
        return RTI;
    }
    else if(strcmp(opcode,ST)==0){
        return ST;
    }
    else if(strcmp(opcode,STR)==0){
        return STR;
    }
    else if(strcmp(opcode,TRAP)==0){
        return TRAP;
    }
    else{
        return "\0";
    }
}
int returninstrtype(char *str){
    for(int i=0;str[i]!='\0';i++){
        if(str[i]==':')
            return i;
    }
    return COMMAN;
}
char* returnopcode(char *str){
    char tempstr[10]={'\0'};
    for(int i=0;str[i]!=' ';i++){
        tempstr[i]=str[i];
    }
    return compareopcode(tempstr);
}
typedef struct symbol{
    int PC;
    string name;
    symbol *next;
}symbol;
int find(symbol *list,string target){
    symbol* pointer=list;
    while(pointer){
        if(pointer->name==target){
            return pointer->PC;
        }
        else{
            pointer=pointer->next;
        }
    }
    return -1;
}
char jump_target[10];
void returnjumptarget(char *str){
    int i;
    for(i=0;str[i]!='\0';i++){
        jump_target[i]=str[i];
    }
    jump_target[i]='\0';
}